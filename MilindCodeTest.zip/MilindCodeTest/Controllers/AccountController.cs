﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using MilindCodeTest.Models;

namespace MilindCodeTest.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {       
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            var userEntity = new Entities1();           
            if (ModelState.IsValid)
            {
                var UserId = userEntity.ValidateUsers("Milind", "Milind123").FirstOrDefault();
                if (UserId > 0)
                {
                    Session["UserId"] = UserId;
                    return RedirectToAction("Notes", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
            }
            return View(model);
        }
    }
}