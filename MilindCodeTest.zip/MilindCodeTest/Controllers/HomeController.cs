﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MilindCodeTest.Models;
using MilindCodeTest.HelperClasses;

namespace MilindCodeTest.Controllers
{
    public class HomeController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            DBHelper _dbHelper = new DBHelper();
            _dbHelper.Insert_ErrorLog(filterContext.Exception.Message);
            // save error to DB
        }
        public ActionResult Index()
        {
            if (Convert.ToString(Session["UserId"]) != "")
            
            return RedirectToAction("Login", "Account");
            else
                return RedirectToAction("Notes", "Home");
        }        

        public ActionResult Notes(UserNotes model)
        {
            if (Convert.ToString(Session["UserId"]) != "")
            {
                DBHelper _dbHelper = new DBHelper();
                model.UserId = Convert.ToInt32(Session["UserId"]);
                model._UserNotes = (List<Get_UserNotes_Result>)_dbHelper.Get_UserNotes(model).ToList();
                return View(model);
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }   
        }

        public ActionResult AddUserNote(UserNotes model)
        {
            model.UserId = Convert.ToInt32(Session["UserId"]);
            DBHelper _dbHelper = new DBHelper();            
            model.IsSuccess = _dbHelper.AddUpdate_UserNotes(model);
            model._UserNotes = (List<Get_UserNotes_Result>)_dbHelper.Get_UserNotes(model).ToList();
            model.NoteId = 0;
            model.Notes = string.Empty;
            ViewBag.Message = "Note Added/Updated Successfully!!";
            return View("Notes", model);
        }

        public ActionResult Delete_Note(int NoteId)
        {
            UserNotes model = new UserNotes();
            model.UserId = Convert.ToInt32(Session["UserId"]);
            model.NoteId = NoteId;
            DBHelper _dbHelper = new DBHelper();
            model.IsSuccess = _dbHelper.Delete_UserNotes(model);
            model._UserNotes = (List<Get_UserNotes_Result>)_dbHelper.Get_UserNotes(model).ToList();
            ViewBag.Message = "Note Deleted Successfully!!!!";
            return View("Notes", model);
        }

        public ActionResult Update_Note(int NoteId)
        {
            UserNotes model = new UserNotes();
            model.UserId = Convert.ToInt32(Session["UserId"]);
            model.NoteId = NoteId;
            DBHelper _dbHelper = new DBHelper();
            List<Get_UserNotesByNoteId_Result> _Get_UserNotesByNoteId_Result =  new List<Get_UserNotesByNoteId_Result>();

            _Get_UserNotesByNoteId_Result = (List<Get_UserNotesByNoteId_Result>)_dbHelper.Get_UserNotesByNoteId(model).ToList();
            model.Notes = _Get_UserNotesByNoteId_Result.FirstOrDefault().Notes;
            //model.IsSuccess = 
            model._UserNotes = (List<Get_UserNotes_Result>)_dbHelper.Get_UserNotes(model).ToList();
            ViewBag.Message = "Note Deleted Successfully!!!!";
            return View("Notes", model);
        }        
    }
}