﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MilindCodeTest.Models;
using System.Data.Entity.Core.Objects;

namespace MilindCodeTest.HelperClasses
{
    public class DBHelper
    {

        public ObjectResult<Get_UserNotes_Result> Get_UserNotes(UserNotes _userNotes)
        {
            var userEntity = new Entities1();
            return userEntity.Get_UserNotes(_userNotes.UserId);
        }

        public int AddUpdate_UserNotes(UserNotes _userNotes)
        {
            var userEntity = new Entities1();
            return userEntity.AddUpdate_UserNotes(_userNotes.NoteId, _userNotes.UserId, _userNotes.Notes);
        }

        public int Delete_UserNotes(UserNotes _userNotes)
        {
            var userEntity = new Entities1();
            return userEntity.Delete_UserNotes(_userNotes.NoteId);
        }

        public ObjectResult<Get_UserNotesByNoteId_Result> Get_UserNotesByNoteId(UserNotes _userNotes)
        {
            var userEntity = new Entities1();
            return userEntity.Get_UserNotesByNoteId(_userNotes.NoteId);
        }

        public int Insert_ErrorLog(string error)
        {
            var userEntity = new Entities1();
            return userEntity.Insert_ErrorLog(error);
        }       
        
    }
}